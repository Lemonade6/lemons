<?php
$message = '';
$post=array();


function fetch_customer_data()
{
      $c1=$c2=$c3=$c4="";
if(isset($_POST['insulated'])){
  $c1="checked";
}
if(isset($_POST['non-insulated'])){
  $c2="checked";
}
if(isset($_POST['2xpressure'])){
  $c3="checked";
}
if(isset($_POST['6xpressure'])){
  $c4="checked";
}

$steel=$_POST['steelSkid']*$_POST['quantity'];
$t_total=$_POST['outputTotal']*$_POST['quantity'];

$vat=0.15*$t_total;

$vat_withTotal=$t_total+$vat;

	$output = '<style>
  .form-control {
    background-color: #e8eeef !important;
    height:25px !important;
    color:#323639 !important;
  }
</style>
	<div class="row">
		<div class="col-md-12 col-xs-12 text-center"><img src="images/logo.jpg" class="img-fluid" alt="Al Maymanah" ></div>
	</div>
	<div class="row">
		<div class="col-md-6 col-xs-6 text-left">Ref: CP2-201.4</div>
		<div class="col-md-6 col-xs-6 text-center"> '.date('M d, Y').'</div>
	</div>
	<div class="row">
  <br>
		<div class="col-md-12 col-xs-12 text-left"><b>To	:</b>&nbsp;&nbsp;&nbsp;&nbsp;'.$_POST['email'].'	</div>
	</div>
	<div class="row">
  <br>
		<div class="col-md-12 col-xs-12 text-left"><b>Attn.	:</b>	</div>
	</div>
	<div class="row">
  <br>
		<div class="col-md-12 col-xs-12 text-left"><b>Sub.	:</b>	GRP TANKS </div>
	</div>
	<div class="row">
  <br>
		<div class="col-md-12 col-xs-12 text-left">Dear '.$_POST['name'].',<br>Thank you for your inquiry of above subject, we are pleased to quote our best prices, as follows:</div>
	</div>

  <div class="row">
  <br>
		<div class="col-md-12 col-xs-12 text-left"><u><b>A.	G.R.P. PANEL TYPE WATER TANK – HITANK – KOREA</b></u>	</div>
	</div>





	<div class="table-responsive" >
  <br>
  <style>.table-bordered td, .table-bordered th {
 vertical-align: middle !important;border: 2px solid #7a7a7a !important;
}thead {display: table-row-group;}.table-bordered>thead>tr>td, .table-bordered>thead>tr>th{ padding: 2px 3px;}.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th{ padding:5px;}.table td{ background-color:#ffffff ;}</style>
<table class="table text-center table-striped table-bordered" page-break-inside: auto;>
 <thead class="thead">
   <tr>
     <th rowspan="2" class="text-center" style="font-size:14px !important;background-color:#d9e1f2 !important;width:100px;">Ref.</th>
     <th rowspan="2" class="text-center" style="font-size:14px !important;background-color:#d9e1f2 !important;width:70px">Location</th>
     <th rowspan="2" class="text-center" style="font-size:14px !important;width: 60px;background-color:#d9e1f2 !important">Capacity</th>
     <th class="text-center" colspan="3" style="font-size:14px !important;background-color:#d9e1f2 !important;width:164px;">Dimensions</th>
     <th rowspan="2" class="text-center" style="font-size:14px !important;background-color:#d9e1f2 !important;width:40px">QTY</th>
     <th rowspan="2" class="text-center" style="font-size:14px !important;background-color:#d9e1f2 !important;width:80px" >Steel skid</th>
     <th rowspan="2" class="text-center" style="font-size:14px !important;background-color:#d9e1f2 !important;width:90px;">T. Price</th>
   </tr>
   <tr>
      <th class="text-center" style="font-size:12px !important;background-color:#d9e1f2 !important;width:54px;">L</th>
      <th class="text-center" style="font-size:12px !important;background-color:#d9e1f2 !important;width:55px;">W</th>
      <th class="text-center" style="font-size:12px !important;background-color:#d9e1f2 !important;width:55px;border-right:3px solid #7a7a7a !important;">H</th>
   </tr>
 </thead>
 <tbody>
  <tr>
       <td  style="font-size:13px !important;width:100px;">CSWT-H-B03-01</td>
       <td  style="font-size:13px !important;width:70px">'.$_POST['location'].'</td>
       <td  style="font-size:13px !important;width:60px">'.$_POST['outputCap'].'</td>
       <td  style="font-size:13px !important;width:54px">'.$_POST['Length'].'</td>
       <td  style="font-size:13px !important;width:55px">'.$_POST['Width'].'</td>
       <td  style="font-size:13px !important;width:55px">'.$_POST['Height'].'</td>
       <td  style="font-size:13px !important;width:40px">'.$_POST['quantity'].'</td>
       <td  style="font-size:13px !important;width:80px">SR. '.$steel.'</td>
       <td  style="font-size:13px !important;width:90px">SR. '.$t_total.'</td>
     </tr>
     <tr>
          <th colspan="8" style="font-size:14px !important;text-align:right;">Total Price</th>
          <th  style="font-size:14px !important;text-align:center;">SR.'.$t_total.'</th>
     </tr>
     <tr>
          <th colspan="8" style="font-size:14px !important;text-align:right;">VAT</th>
          <th  style="font-size:14px !important;text-align:center;">SR. '.$vat.'</th>
     </tr>
     <tr>
          <th colspan="8" style="font-size:14px !important;text-align:right;">Total Price Including VAT</th>
          <th  style="font-size:14px !important;text-align:center;">SR. '.$vat_withTotal.'</th>
     </tr>
 </tbody>
 </table>
 
 <div class="row">
		<div class="col-md-12 col-xs-12 text-left"><u><b>Tank Specifications whichever applicable for quoted tanks:</b></u>	</div>
	</div>
  <div>
  <fieldset>

    <br><br>
    <label>Choose the following:</label><br>
    <input type="checkbox" value="1.15" '.$c1.' name="insulated"><label class="light"> &nbsp;Insulated</label><br>
    <input type="checkbox" value="" '.$c2.' name="non-insulated"><label class="light"> &nbsp;Non-insulated</label><br><br>

    <label>Choose the following:</label><br>
    <input type="checkbox" value="" '.$c3.' name="2xpressure"><label class="light"> &nbsp;2X Pressure</label><br>
    <input type="checkbox" value="1.15" '.$c4.' name="6xpressure"><label class="light"> &nbsp;6X Pressure</label>
  </fieldset>
  </div>';
	return $output;
}



if(isset($_POST["generate"]))
{
    include('pdf.php');
	$file_name = md5(rand()) . '.pdf';
	$html_code = '<link rel="stylesheet" href="bootstrap.min.css">';
	$html_code .= fetch_customer_data();
	$pdf = new Pdf();
	$pdf->load_html($html_code);
	$pdf->render();
    $pdf->stream($file_name.".pdf", array("Attachment"=>0));

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>GRP Tanks</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>


<form action="" id="GRPform" method="post">

    <h1>GRP Tank Quote</h1>
    <!-- <div class="text-right"><a href="#" class="btn btn-primary" id="addScnt"><i class="fa fa-plus" aria-hidden="true"></i> Add</a></div> -->
    <fieldset>
    
    <div class="row">
        <div class="col-lg-6">
            <label for="Name">Customer Name:</label>
            <input type="text" id="Name" name="name" placeholder="Enter the Your Name" required>
        </div>
        <div class="col-lg-6">
            <label for="Email">Customer Email:</label>
            <input type="email" id="Email" name="email" placeholder="Enter the Your Email" required>  
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-4">
            <label for="validity">Validity of quote <span data-toggle="tooltip" data-placement="top" title="Enter the duration that this quote will be valid"><i class="fa fa-question-circle" aria-hidden="true"></i></span> :</label>
            <input type="text" id="validity" name="validity" placeholder="e.g 15 Days" required>
        </div>
        <div class="col-lg-4">
            <label for="delivery">Delivery Time <span data-toggle="tooltip" data-placement="top" title="Enter the estimated delivery time of this job"><i class="fa fa-question-circle" aria-hidden="true"></i> :</label>
            <input type="text" id="delivery" name="delivery" placeholder="e.g 10 Weeks" required>  
        </div>
        <div class="col-lg-4">
            <label for="payment">Select Payment:</label>
            <select id="payment" name="payment" class="" placeholder="Select Payment" required>
                <option value="" disabled selected>- Please Select -</option>
                <option value="50% with order – 50% on delivery">50% with order – 50% on delivery</option> 
                <option value="Full">Full Upfront</option> 
            </select>
        </div>
    </div>
      
      
    <div class="row">
        <div class="col-lg-6">
            <label for="location" >Location <span data-toggle="tooltip" data-placement="top" title="Location of Tank"><i class="fa fa-question-circle" aria-hidden="true"></i></span> :</label>
            <input type="text" id="location" name="location" placeholder="Location of Project" required>
        </div>
        <div class="col-lg-6">
            <label for="Quantity">Quantity <span data-toggle="tooltip" data-placement="top" title="Quantity of Tank Required"><i class="fa fa-question-circle" aria-hidden="true"></i></span>  :</label>
            <input type="number" id="quantity" name="quantity" placeholder="Qunatity of tanks e.g 1" required> 
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <label for="tankdimensions"><b>Dimensions of tank <span data-toggle="tooltip" data-placement="top" title="Enter Tank dimensions"><i class="fa fa-question-circle" aria-hidden="true"></i></span> :</b></label>
        </div>
        <div class="col-lg-4">
            <input type="number"  id="Length" name="Length" placeholder="Length in meters"  required>
        </div>
        <div class="col-lg-4">
            <input type="number" id="Width" name="Width" placeholder="Width in meters" required>
        </div>
        <div class="col-lg-4">
            <input type="number" id="Height" name="Height" placeholder="Height in meters" oninput="DisplayF()" required>
        </div>
    </div>
      
      <div style="padding:20px; margin:6px; font-size:18px;color:red;display:none;" id="Display-F"></div>
      <input type="hidden" id="outputCap" name="outputCap" >
      <input type="hidden" id="skid" name="steelSkid" >
      
      
     <div class="row">
        <div class="col-lg-6">
            <label><b>Choose the following:</b></label><br>
            <input type="checkbox"  value="1.15" name="insulated" id="insulated"><label class="light">Insulated</label><br>
            <input type="checkbox"  value="" name="non-insulated"><label  class="light">Non-insulated</label><br><br>
        </div>
        <div class="col-lg-6">
            <label><b>Choose Pump Pressure:</b></label><br>
            <input type="checkbox"   value="" name="2xpressure" ><label  class="light">2X Pressure</label><br>
            <input type="checkbox"  value="1.15" name="6xpressure" id="6xpressure"><label  class="light">6X Pressure</label>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <label for="tankdimensions"><b>Tank Specifications <span data-toggle="tooltip" data-placement="top" title="Choose the applicable tank specifications for this quotation"><i class="fa fa-question-circle" aria-hidden="true"></i></span> :</b></label>
        </div>
        <div class="col-lg-12">
            <input type="checkbox"  value="Brand (HI TANK) made in South Korea." name="specifications[]" id="specifications"><label class="light">Brand (HI TANK) made in South Korea.</label><br>
            <input type="checkbox"  value="Base Steel skid (HDG) and anchor bolts (HDG)." name="specifications[]" id="specifications"><label class="light">Base Steel skid (HDG) and anchor bolts (HDG).</label><br>
            <input type="checkbox"  value="One Manholes (dia. 900mm) with lockable cover per tank." name="specifications[]" id="specifications"><label class="light">One Manholes (dia. 900mm) with lockable cover per tank.</label><br>
            <input type="checkbox"  value="Air-vents in ABS with PE-mesh insect guard. / PVC sealant tape." name="specifications[]" id="specifications"><label class="light">Air-vents in ABS with PE-mesh insect guard. / PVC sealant tape.</label><br>
            <input type="checkbox"  value="Water Level Indicator" name="specifications[]" id="specifications"><label class="light">Water Level Indicator</label><br>
            <input type="checkbox"  value="External steel accessories: HDG steel." name="specifications[]" id="specifications"><label class="light">External steel accessories: HDG steel.</label><br>
            <input type="checkbox"  value="Bolts for internal: SS316, External Bolts: HDG" name="specifications[]" id="specifications"><label class="light">Bolts for internal: SS316, External Bolts: HDG</label><br>
            <input type="checkbox"  value="Internal PVC & External HDG Ladders" name="specifications[]" id="specifications"><label class="light">Internal PVC & External HDG Ladders</label><br>
            <input type="checkbox"  value="External Reinforcement System" name="specifications[]" id="specifications"><label class="light">External Reinforcement System</label><br>
        </div>
    </div>

    </fieldset>


    <button type="button" onclick="costTotal()">Calculate</button>
    <div style= "padding:20px; margin:20px;border: solid 1px black;font-size:18px;color:red;" id="totalPrice"></div>
    <input type="hidden" id="outputTotal" name="outputTotal" >
    <div class="container text-center mt-4  d-none" id="pdf">
    <input type="submit" name="generate" class="btn btn-success" value="Save PDF" />&emsp;
		</div>
  </form>

<footer class="bg-dark">
	<div class="container">
		<p class="text-white mb-0">© Al Maymanah</p>
	</div>
</footer>
<!-- required js files for botstrap  -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
function DisplayF()
{
  var Length = parseFloat($("#Length").val());
  var Width = parseFloat($("#Width").val());
  var Height = parseFloat($("#Height").val());
  var a = Length * Width;
  var b = Width * Height;
  var c = Length * Height;
  var F1 = a + b + c;
  var F = F1 * 2;
  $('#outputCap').val(F);
  $('#Display-F').css('display','block');
  $('#Display-F').html("Total Tank Capacity "+F +"m<sup>2</sup>");
}
function GetK()
{
 var F =$('#outputCap').val();
 var Height = parseFloat($("#Height").val());
 // here we are calculating the steel skids against the height
  if(Height == 1){
    var K = F * 200;
  }
  if(Height == 1.5){
    var K = F * 200;
  }
  if(Height == 2){
    var K = F * 275;
  }
  if(Height == 2.5){
    var K = F * 275;
  }
  if(Height == 3){
    var K = F * 275;
  }
  if(Height == 3.5){
    var K = F * 300;
  }
  if(Height == 4){
    var K = F * 350;
  }
  return K;
}
function getk1()
{
  // de
  var insulated = $("#insulated");
  var mxpressure = $("#6xpressure");
  var insulate = 1.15;
  var K = GetK();
  $("#skid").val(K);
     if(insulated.prop('checked') == true && mxpressure.prop('checked') == false){
     var k1 = K * 1.15;
     }
     if(insulated.prop('checked') == false && mxpressure.prop('checked') == true){
       var k1 = K * 1.15;
       }
     if(insulated.prop('checked') == true && mxpressure.prop('checked') == true){
       var k1 = K * 1.30;
       }
     if(insulated.prop('checked') == false && mxpressure.prop('checked') == false){
       return K;
     }

      return Math.round(k1);
}

function costTotal()
{
  var Length = parseFloat($("#Length").val());
  var Width = parseFloat($("#Width").val());
  

 var a = Length * Width;
 var g = a * 250;
 var FP = g + getk1();
 var SP = FP * 2;
 
 var q = $("#quantity").val();
    if(q){
        SP=SP*q;
    }

    // divobj.innerHTML = "Total Cost is S.R."+SP;
    $('#totalPrice').css('display','block');
    $('#totalPrice').html("Total Cost is S.R."+SP);
    $('#outputTotal').val(SP);
    $('#pdf').removeClass("d-none");
}

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});
		</script>

</body>
</html>
